# from fastapi import FastAPI

# app = FastAPI()

# @app.get("/")
# def read_root():
#   return{"Hello":"World"}

# This is a basic code snippet of fast API and it will be used to send requests to the LLM models receive the output and print it on the website according to the needs
